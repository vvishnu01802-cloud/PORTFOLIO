import { motion } from "motion/react";
import { Section } from "./Section";
import { Award, Code2, Briefcase, GraduationCap, Cpu } from "lucide-react";

const stats = [
  { icon: GraduationCap, label: "CGPA", value: "8.02" },
  { icon: Code2, label: "Projects", value: "5+" },
  { icon: Award, label: "Certifications", value: "6+" },
  { icon: Briefcase, label: "Internships", value: "3" },
  { icon: Cpu, label: "Tech Skills", value: "15+" },
];

export function About() {
  return (
    <Section
      id="about"
      eyebrow="About Me"
      title="Who I Am"
      subtitle="Motivated CSE (Cyber Security) student passionate about crafting secure, elegant digital experiences."
    >
      <div className="grid gap-10 lg:grid-cols-5">
        <motion.div
          initial={{ opacity: 0, x: -30 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="glass rounded-2xl p-8 lg:col-span-2"
        >
          <h3 className="mb-4 text-2xl font-bold">Professional Summary</h3>
          <p className="text-muted-foreground leading-relaxed">
            Motivated Computer Science and Engineering (Cyber Security) student
            with expertise in Frontend Development, Java Programming, and Cyber
            Security. Skilled in developing secure and responsive applications
            while continuously learning emerging technologies.
          </p>
          <div className="mt-6 rounded-xl border border-neon-purple/30 bg-background/40 p-4">
            <div className="text-xs font-mono uppercase tracking-widest text-neon-cyan">
              Education
            </div>
            <div className="mt-1 font-semibold">B.E CSE (Cyber Security)</div>
            <div className="text-sm text-muted-foreground">
              KSR Institute for Engineering and Technology · 2023 – 2027
            </div>
          </div>
        </motion.div>

        <div className="grid grid-cols-2 gap-4 lg:col-span-3 sm:grid-cols-3">
          {stats.map((s, i) => (
            <motion.div
              key={s.label}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.08, duration: 0.5 }}
              whileHover={{ y: -6, scale: 1.03 }}
              className="glass group relative overflow-hidden rounded-2xl p-6"
            >
              <div className="absolute -right-6 -top-6 h-24 w-24 rounded-full bg-neon-blue/20 blur-2xl transition-all group-hover:bg-neon-purple/30" />
              <s.icon className="text-neon-cyan" size={28} />
              <div className="mt-4 text-4xl font-black neon-text">{s.value}</div>
              <div className="mt-1 text-xs uppercase tracking-wider text-muted-foreground">
                {s.label}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </Section>
  );
}
