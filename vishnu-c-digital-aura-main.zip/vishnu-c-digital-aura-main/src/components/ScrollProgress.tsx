import { motion, useScroll, useSpring } from "motion/react";

export function ScrollProgress() {
  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, { stiffness: 100, damping: 30 });
  return (
    <motion.div
      className="fixed top-0 left-0 right-0 z-50 h-0.5 origin-left"
      style={{
        scaleX,
        background: "linear-gradient(90deg, oklch(0.7 0.24 250), oklch(0.65 0.28 305), oklch(0.85 0.18 200))",
        boxShadow: "0 0 10px oklch(0.7 0.24 250 / 0.8)",
      }}
    />
  );
}
