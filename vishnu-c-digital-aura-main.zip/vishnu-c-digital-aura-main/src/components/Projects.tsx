import { motion, useMotionValue, useTransform } from "motion/react";
import { Section } from "./Section";
import { Github, ExternalLink } from "lucide-react";
import portfolioImg from "@/assets/project-portfolio.jpg";
import netflixImg from "@/assets/project-netflix.jpg";
import type { MouseEvent } from "react";

const projects = [
  {
    title: "Portfolio Website",
    description:
      "Responsive personal portfolio built with HTML, CSS, and JavaScript — clean layouts, smooth interactions, and a modern feel.",
    stack: ["HTML5", "CSS3", "JavaScript"],
    image: portfolioImg,
    github: "https://github.com",
    live: "#",
  },
  {
    title: "Netflix Clone",
    description:
      "Netflix-inspired responsive frontend replicating hero banners, category rows, and hover interactions.",
    stack: ["HTML5", "CSS3", "JavaScript"],
    image: netflixImg,
    github: "https://github.com",
    live: "#",
  },
];

function TiltCard({ project, i }: { project: typeof projects[0]; i: number }) {
  const x = useMotionValue(0);
  const y = useMotionValue(0);
  const rX = useTransform(y, [-50, 50], [8, -8]);
  const rY = useTransform(x, [-50, 50], [-8, 8]);

  const onMove = (e: MouseEvent<HTMLDivElement>) => {
    const r = e.currentTarget.getBoundingClientRect();
    x.set(e.clientX - r.left - r.width / 2);
    y.set(e.clientY - r.top - r.height / 2);
  };
  const onLeave = () => { x.set(0); y.set(0); };

  return (
    <motion.div
      initial={{ opacity: 0, y: 40 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ delay: i * 0.15 }}
      onMouseMove={onMove}
      onMouseLeave={onLeave}
      style={{ rotateX: rX, rotateY: rY, transformStyle: "preserve-3d" }}
      className="glass group relative overflow-hidden rounded-3xl"
    >
      <div className="relative overflow-hidden">
        <img
          src={project.image}
          alt={project.title}
          loading="lazy"
          width={1024}
          height={640}
          className="h-56 w-full object-cover transition-transform duration-700 group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/40 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-br from-neon-blue/0 to-neon-purple/0 opacity-0 transition-opacity group-hover:opacity-20" />
      </div>
      <div className="p-6" style={{ transform: "translateZ(30px)" }}>
        <h3 className="text-2xl font-bold">{project.title}</h3>
        <p className="mt-2 text-sm text-muted-foreground">{project.description}</p>
        <div className="mt-4 flex flex-wrap gap-2">
          {project.stack.map((t) => (
            <span
              key={t}
              className="glass-strong rounded-full px-3 py-1 text-xs font-mono text-neon-cyan"
            >
              {t}
            </span>
          ))}
        </div>
        <div className="mt-6 flex gap-3">
          <a
            href={project.github}
            target="_blank" rel="noreferrer"
            className="glass-strong inline-flex items-center gap-2 rounded-full px-4 py-2 text-sm hover:text-neon-cyan"
          >
            <Github size={16} /> Code
          </a>
          <a
            href={project.live}
            className="inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-neon-blue to-neon-purple px-4 py-2 text-sm font-semibold text-white"
          >
            <ExternalLink size={16} /> Live
          </a>
        </div>
      </div>
    </motion.div>
  );
}

export function Projects() {
  return (
    <Section
      id="projects"
      eyebrow="Featured Work"
      title="Projects"
      subtitle="A selection of things I've designed, coded, and shipped."
    >
      <div className="grid gap-8 md:grid-cols-2" style={{ perspective: 1200 }}>
        {projects.map((p, i) => (
          <TiltCard key={p.title} project={p} i={i} />
        ))}
      </div>
    </Section>
  );
}
