import { motion } from "motion/react";
import { useState } from "react";
import { Section } from "./Section";
import { Phone, Mail, Github, Linkedin, Send, CheckCircle2 } from "lucide-react";

export function Contact() {
  const [sent, setSent] = useState(false);
  const [form, setForm] = useState({ name: "", email: "", message: "" });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const errs: Record<string, string> = {};
    if (!form.name.trim()) errs.name = "Name is required";
    if (!/^\S+@\S+\.\S+$/.test(form.email)) errs.email = "Valid email required";
    if (form.message.trim().length < 10) errs.message = "Message too short";
    setErrors(errs);
    if (Object.keys(errs).length) return;
    setSent(true);
    setTimeout(() => { setSent(false); setForm({ name: "", email: "", message: "" }); }, 3000);
  };

  const contacts = [
    { icon: Phone, label: "Phone", value: "+91 8838046662", href: "tel:+918838046662" },
    { icon: Mail, label: "Email", value: "vvishnu01802@gmail.com", href: "mailto:vvishnu01802@gmail.com" },
    { icon: Github, label: "GitHub", value: "@vishnu-c", href: "https://github.com" },
    { icon: Linkedin, label: "LinkedIn", value: "Vishnu C", href: "https://linkedin.com" },
  ];

  return (
    <Section
      id="contact"
      eyebrow="Get in Touch"
      title="Let's Build Something"
      subtitle="Open to internships, freelance work, and collaboration opportunities."
    >
      <div className="grid gap-8 lg:grid-cols-2">
        <div className="space-y-4">
          {contacts.map((c, i) => (
            <motion.a
              key={c.label}
              href={c.href}
              target={c.href.startsWith("http") ? "_blank" : undefined}
              rel="noreferrer"
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.08 }}
              whileHover={{ x: 6 }}
              className="glass group flex items-center gap-4 rounded-2xl p-5"
            >
              <div className="glass-strong grid h-12 w-12 place-items-center rounded-xl text-neon-cyan transition-all group-hover:neon-glow">
                <c.icon size={20} />
              </div>
              <div>
                <div className="text-xs uppercase tracking-wider text-muted-foreground">{c.label}</div>
                <div className="font-semibold">{c.value}</div>
              </div>
            </motion.a>
          ))}
        </div>

        <motion.form
          onSubmit={submit}
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="glass rounded-2xl p-8 space-y-4"
        >
          <div>
            <label className="mb-2 block text-xs font-mono uppercase tracking-widest text-neon-cyan">Name</label>
            <input
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              className="w-full rounded-xl border border-border bg-input px-4 py-3 text-sm outline-none transition-all focus:border-neon-purple focus:neon-glow"
              placeholder="Your name"
            />
            {errors.name && <p className="mt-1 text-xs text-destructive">{errors.name}</p>}
          </div>
          <div>
            <label className="mb-2 block text-xs font-mono uppercase tracking-widest text-neon-cyan">Email</label>
            <input
              type="email"
              value={form.email}
              onChange={(e) => setForm({ ...form, email: e.target.value })}
              className="w-full rounded-xl border border-border bg-input px-4 py-3 text-sm outline-none transition-all focus:border-neon-purple focus:neon-glow"
              placeholder="you@email.com"
            />
            {errors.email && <p className="mt-1 text-xs text-destructive">{errors.email}</p>}
          </div>
          <div>
            <label className="mb-2 block text-xs font-mono uppercase tracking-widest text-neon-cyan">Message</label>
            <textarea
              value={form.message}
              onChange={(e) => setForm({ ...form, message: e.target.value })}
              rows={5}
              className="w-full resize-none rounded-xl border border-border bg-input px-4 py-3 text-sm outline-none transition-all focus:border-neon-purple focus:neon-glow"
              placeholder="Tell me about your project..."
            />
            {errors.message && <p className="mt-1 text-xs text-destructive">{errors.message}</p>}
          </div>
          <motion.button
            type="submit"
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            disabled={sent}
            className="animate-pulse-glow inline-flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-neon-blue to-neon-purple px-6 py-3 font-semibold text-white"
          >
            {sent ? (<><CheckCircle2 size={18} /> Message Sent!</>) : (<><Send size={18} /> Send Message</>)}
          </motion.button>
        </motion.form>
      </div>
    </Section>
  );
}
