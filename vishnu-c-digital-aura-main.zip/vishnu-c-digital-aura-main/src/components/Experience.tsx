import { motion } from "motion/react";
import { Section } from "./Section";
import { Briefcase } from "lucide-react";

const items = [
  {
    company: "United Soft Tech, Salem",
    role: "Network Security Intern",
    date: "July 2024",
  },
  {
    company: "Xplore IT Corp, Coimbatore",
    role: "Cyber Security Intern",
    date: "June 2025",
  },
  {
    company: "EduSkills",
    role: "Java Full Stack Developer Virtual Intern",
    date: "2025",
  },
];

export function Experience() {
  return (
    <Section
      id="experience"
      eyebrow="Journey"
      title="Internships & Experience"
      subtitle="Hands-on learning across network security, offensive security, and full-stack development."
    >
      <div className="relative mx-auto max-w-3xl">
        <div className="absolute left-4 top-0 h-full w-0.5 bg-gradient-to-b from-neon-blue via-neon-purple to-neon-cyan md:left-1/2 md:-translate-x-1/2" />
        {items.map((item, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.15 }}
            className={`relative mb-12 flex ${i % 2 === 0 ? "md:justify-start" : "md:justify-end"}`}
          >
            <div className="absolute left-4 top-4 grid h-8 w-8 -translate-x-1/2 place-items-center rounded-full bg-gradient-to-br from-neon-blue to-neon-purple neon-glow md:left-1/2">
              <Briefcase size={14} className="text-white" />
            </div>
            <motion.div
              whileHover={{ scale: 1.02, y: -4 }}
              className={`glass ml-16 w-full rounded-2xl p-6 md:ml-0 md:w-[45%] ${i % 2 === 0 ? "md:mr-auto" : "md:ml-auto"}`}
            >
              <div className="font-mono text-xs uppercase tracking-widest text-neon-cyan">
                {item.date}
              </div>
              <h3 className="mt-2 text-lg font-bold">{item.role}</h3>
              <p className="text-sm text-muted-foreground">{item.company}</p>
            </motion.div>
          </motion.div>
        ))}
      </div>
    </Section>
  );
}
