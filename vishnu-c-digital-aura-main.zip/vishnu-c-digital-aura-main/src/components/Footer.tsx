export function Footer() {
  return (
    <footer className="border-t border-border/40 py-8">
      <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-4 px-6 sm:flex-row">
        <div className="font-display text-sm neon-text">&lt;VC/&gt; · Vishnu C</div>
        <div className="text-xs text-muted-foreground">
          © {new Date().getFullYear()} Vishnu C · Crafted with React, Motion & lots of coffee.
        </div>
      </div>
    </footer>
  );
}
