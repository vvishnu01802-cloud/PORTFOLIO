import { motion } from "motion/react";
import { Section } from "./Section";
import { Award } from "lucide-react";

const certs = [
  { title: "Full Stack Development", issuer: "NOVI Tech Pvt Ltd" },
  { title: "Java Full Stack Developer", issuer: "EduSkills" },
  { title: "React.js", issuer: "Unstop" },
  { title: "CSS with AI", issuer: "Unstop" },
  { title: "HTML5 Essentials", issuer: "Infosys Springboard" },
  { title: "NPTEL Certificate", issuer: "NPTEL" },
];

const achievements = [
  { category: "Workshop", title: "AI Prompt Engineering", venue: "Mahendra Engineering College" },
  { category: "Workshop", title: "DevOps", venue: "Karpagam Institute of Technology" },
  { category: "Hackathon", title: "IoT Automated Car Parking", venue: "SNS College of Engineering" },
  { category: "Paper", title: "Zero Trust", venue: "Karpagam Institute of Technology" },
];

export function Certifications() {
  return (
    <Section
      id="certifications"
      eyebrow="Credentials"
      title="Certifications & Achievements"
      subtitle="Continuous learning through certified programs, workshops, and competitions."
    >
      <div className="mb-10">
        <h3 className="mb-6 text-center font-mono text-xs uppercase tracking-[0.3em] text-neon-cyan">
          — Certifications —
        </h3>
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {certs.map((c, i) => (
            <motion.div
              key={c.title}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.06 }}
              whileHover={{ y: -6 }}
              className="glass group relative overflow-hidden rounded-2xl p-6"
            >
              <div
                className="absolute inset-0 opacity-0 transition-opacity group-hover:opacity-100 animate-gradient"
                style={{
                  background: "linear-gradient(135deg, oklch(0.7 0.24 250 / 0.15), oklch(0.65 0.28 305 / 0.15), oklch(0.85 0.18 200 / 0.15))",
                }}
              />
              <Award className="relative text-neon-cyan" size={28} />
              <h4 className="relative mt-3 font-bold">{c.title}</h4>
              <p className="relative mt-1 text-sm text-muted-foreground">{c.issuer}</p>
            </motion.div>
          ))}
        </div>
      </div>

      <div>
        <h3 className="mb-6 text-center font-mono text-xs uppercase tracking-[0.3em] text-neon-cyan">
          — Achievements —
        </h3>
        <div className="grid gap-5 sm:grid-cols-2">
          {achievements.map((a, i) => (
            <motion.div
              key={a.title}
              initial={{ opacity: 0, x: i % 2 === 0 ? -30 : 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.08 }}
              whileHover={{ scale: 1.02 }}
              className="glass rounded-2xl p-6"
            >
              <div className="mb-2 inline-block rounded-full bg-neon-purple/20 px-3 py-1 text-xs font-mono uppercase text-neon-purple">
                {a.category}
              </div>
              <h4 className="font-bold">{a.title}</h4>
              <p className="mt-1 text-sm text-muted-foreground">{a.venue}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </Section>
  );
}
