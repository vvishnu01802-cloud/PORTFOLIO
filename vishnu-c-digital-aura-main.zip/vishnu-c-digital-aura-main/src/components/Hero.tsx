import { motion } from "motion/react";
import { useEffect, useState } from "react";
import { Download, Mail, Github, Linkedin, Twitter } from "lucide-react";
import heroAvatar from "@/assets/hero-avatar.jpg";

const titles = ["Frontend Developer", "Java Programmer", "Cyber Security Enthusiast"];

function TypeWriter() {
  const [idx, setIdx] = useState(0);
  const [text, setText] = useState("");
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    const current = titles[idx];
    const timeout = setTimeout(() => {
      if (!deleting) {
        setText(current.slice(0, text.length + 1));
        if (text.length + 1 === current.length) {
          setTimeout(() => setDeleting(true), 1500);
        }
      } else {
        setText(current.slice(0, text.length - 1));
        if (text.length - 1 === 0) {
          setDeleting(false);
          setIdx((idx + 1) % titles.length);
        }
      }
    }, deleting ? 40 : 80);
    return () => clearTimeout(timeout);
  }, [text, deleting, idx]);

  return (
    <span className="neon-text font-display">
      {text}
      <span className="animate-blink ml-1 text-neon-purple">|</span>
    </span>
  );
}

export function Hero() {
  return (
    <section id="home" className="relative flex min-h-screen items-center overflow-hidden pt-24 pb-16">
      <div className="grid-bg absolute inset-0 opacity-40" />
      <div className="mx-auto grid max-w-7xl grid-cols-1 gap-12 px-6 lg:grid-cols-2 lg:gap-16">
        <motion.div
          initial={{ opacity: 0, x: -40 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8 }}
          className="flex flex-col justify-center"
        >
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="glass mb-6 inline-flex w-fit items-center gap-2 rounded-full px-4 py-1.5 text-xs"
          >
            <span className="relative flex h-2 w-2">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-neon-cyan opacity-75" />
              <span className="relative inline-flex h-2 w-2 rounded-full bg-neon-cyan" />
            </span>
            <span className="text-muted-foreground">Available for opportunities</span>
          </motion.div>

          <h1 className="text-5xl font-black leading-[1.05] sm:text-6xl lg:text-7xl">
            Hi, I'm <span className="neon-text">Vishnu C</span>
          </h1>

          <div className="mt-6 text-2xl font-semibold sm:text-3xl min-h-[2.5rem]">
            <TypeWriter />
          </div>

          <p className="mt-6 max-w-xl text-base text-muted-foreground sm:text-lg">
            Building Secure, Responsive, and Interactive Digital Experiences —
            fusing frontend craft with cyber security fundamentals.
          </p>

          <div className="mt-8 flex flex-wrap gap-4">
            <motion.a
              whileHover={{ scale: 1.05, y: -2 }}
              whileTap={{ scale: 0.97 }}
              href="/resume.pdf"
              download
              className="animate-pulse-glow inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-neon-blue to-neon-purple px-6 py-3 text-sm font-semibold text-white"
            >
              <Download size={18} /> Download Resume
            </motion.a>
            <motion.a
              whileHover={{ scale: 1.05, y: -2 }}
              whileTap={{ scale: 0.97 }}
              href="#contact"
              className="glass-strong inline-flex items-center gap-2 rounded-full px-6 py-3 text-sm font-semibold"
            >
              <Mail size={18} /> Contact Me
            </motion.a>
          </div>

          <div className="mt-10 flex items-center gap-4">
            {[
              { icon: Github, href: "https://github.com" },
              { icon: Linkedin, href: "https://linkedin.com" },
              { icon: Twitter, href: "https://twitter.com" },
              { icon: Mail, href: "mailto:vvishnu01802@gmail.com" },
            ].map(({ icon: Icon, href }, i) => (
              <motion.a
                key={i}
                href={href}
                target="_blank"
                rel="noreferrer"
                whileHover={{ y: -4, scale: 1.15 }}
                className="glass grid h-11 w-11 place-items-center rounded-full text-muted-foreground hover:text-neon-cyan"
                aria-label="Social link"
              >
                <Icon size={18} />
              </motion.a>
            ))}
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="relative flex items-center justify-center"
        >
          <div className="animate-float relative">
            <div className="absolute inset-0 -z-10 rounded-full bg-gradient-to-br from-neon-blue via-neon-purple to-neon-cyan opacity-40 blur-3xl" />
            <div className="glass-strong relative overflow-hidden rounded-3xl p-2">
              <div className="absolute inset-0 rounded-3xl border border-neon-purple/40" />
              <img
                src={heroAvatar}
                alt="Vishnu C"
                width={768}
                height={896}
                className="h-[420px] w-[360px] rounded-2xl object-cover sm:h-[500px] sm:w-[420px]"
              />
              <div className="absolute inset-2 rounded-2xl bg-gradient-to-t from-background/80 via-transparent to-transparent" />
            </div>
            {["React", "Java", "CyberSec"].map((t, i) => (
              <motion.div
                key={t}
                animate={{ y: [0, -10, 0] }}
                transition={{ duration: 3 + i, repeat: Infinity, delay: i * 0.5 }}
                className="glass-strong absolute rounded-full px-4 py-2 text-xs font-mono neon-glow"
                style={{
                  top: `${20 + i * 30}%`,
                  [i % 2 === 0 ? "left" : "right"]: "-20px",
                }}
              >
                {t}
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
