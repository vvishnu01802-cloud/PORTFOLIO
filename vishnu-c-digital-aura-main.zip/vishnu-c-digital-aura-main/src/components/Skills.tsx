import { motion } from "motion/react";
import { Section } from "./Section";
import { Code, Layout, Shield, Monitor, Users } from "lucide-react";

const groups = [
  {
    icon: Code,
    title: "Programming",
    skills: [
      { name: "Java", level: 88 },
      { name: "JavaScript", level: 82 },
    ],
  },
  {
    icon: Layout,
    title: "Frontend",
    skills: [
      { name: "React.js", level: 85 },
      { name: "Tailwind CSS", level: 90 },
      { name: "HTML5 / CSS3", level: 92 },
      { name: "Responsive Design", level: 88 },
    ],
  },
  {
    icon: Shield,
    title: "Cyber Security",
    skills: [
      { name: "Nmap", level: 80 },
      { name: "Wireshark", level: 78 },
      { name: "Burp Suite", level: 75 },
      { name: "Network Security", level: 82 },
    ],
  },
  {
    icon: Monitor,
    title: "Operating Systems",
    skills: [
      { name: "Kali Linux", level: 80 },
      { name: "Windows", level: 90 },
    ],
  },
  {
    icon: Users,
    title: "Soft Skills",
    skills: [
      { name: "Communication", level: 88 },
      { name: "Teamwork", level: 92 },
      { name: "Problem Solving", level: 90 },
    ],
  },
];

function Bar({ name, level }: { name: string; level: number }) {
  return (
    <div>
      <div className="mb-1.5 flex justify-between text-sm">
        <span>{name}</span>
        <span className="font-mono text-neon-cyan">{level}%</span>
      </div>
      <div className="h-2 overflow-hidden rounded-full bg-secondary">
        <motion.div
          initial={{ width: 0 }}
          whileInView={{ width: `${level}%` }}
          viewport={{ once: true }}
          transition={{ duration: 1.2, ease: "easeOut" }}
          className="h-full rounded-full bg-gradient-to-r from-neon-blue via-neon-purple to-neon-cyan"
          style={{ boxShadow: "0 0 12px oklch(0.7 0.24 250 / 0.8)" }}
        />
      </div>
    </div>
  );
}

export function Skills() {
  return (
    <Section
      id="skills"
      eyebrow="Technical Arsenal"
      title="Skills & Expertise"
      subtitle="A blend of frontend craftsmanship, backend fundamentals, and offensive security tooling."
    >
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {groups.map((g, i) => (
          <motion.div
            key={g.title}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.08 }}
            whileHover={{ y: -6 }}
            className="glass group relative overflow-hidden rounded-2xl p-6"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-neon-blue/0 via-neon-purple/0 to-neon-cyan/0 opacity-0 transition-opacity group-hover:opacity-10" />
            <div className="mb-5 flex items-center gap-3">
              <div className="glass-strong grid h-11 w-11 place-items-center rounded-xl text-neon-cyan">
                <g.icon size={20} />
              </div>
              <h3 className="text-lg font-bold">{g.title}</h3>
            </div>
            <div className="space-y-4">
              {g.skills.map((s) => (
                <Bar key={s.name} {...s} />
              ))}
            </div>
          </motion.div>
        ))}
      </div>
    </Section>
  );
}
